import { Component } from '@angular/core';
import { DishService } from '../services/dish.service';

@Component({
  selector: 'app-footer',
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css',
  // providers: [DishService]
})
export class FooterComponent {
  // s:DishService = new DishService();
  constructor(public s:DishService) {
  }
}
