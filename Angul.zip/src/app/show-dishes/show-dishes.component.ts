import { Component, Input } from '@angular/core';
import { Dish } from '../models/dish';
import { DishService } from '../services/dish.service';

@Component({
  selector: 'app-show-dishes',
  imports: [],
  templateUrl: './show-dishes.component.html',
  styleUrl: './show-dishes.component.css'
})
export class ShowDishesComponent {
@Input() items:Array<Dish> = [];
data:Array<Dish> = [];
  constructor(private ds:DishService) {
    this.ds.getDishes().subscribe(d => {
      this.data = d;
    })
  }
}


