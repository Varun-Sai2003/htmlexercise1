import { Component } from '@angular/core';
import { Dish } from '../models/dish';
import { FormsModule } from '@angular/forms';
import { ShowDishesComponent } from "../show-dishes/show-dishes.component";
import { DishService } from '../services/dish.service';

@Component({
  selector: 'app-add-dish',
  imports: [FormsModule, ShowDishesComponent],
  templateUrl: './add-dish.component.html',
  styleUrl: './add-dish.component.css'
})
export class AddDishComponent {
  
  d:Dish = new Dish();
  namestyle = "background-color: #F8F4FF";
  constructor(public ds:DishService) {

  }

  addHandler(){
    this.ds.addDish(this.d);
    this.d = new Dish();
  }
}
 