import { Injectable } from '@angular/core';
import { Dish } from '../models/dish';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DishService {
  mesg:string = 'Diddy';
  dishes:Array<Dish> = [];

  constructor(private client:HttpClient) { 
    this.client.get('http://localhost:3000/dishes')
    .subscribe(data => {
      console.log(JSON.stringify(data));
      // this.dishes = data as Array<Dish>;
    })
  }

  getDishes():Observable<Array<Dish>>{
    return this.client.get<Array<Dish>>('http://localhost:3000/dishes')
  }
  addDish(d:Dish){
    // this.dishes.push(d);
    this.client.post('http://localhost:3000/dishes', d)
    .subscribe((d) => {
      alert('Dish added successfully');
    })
  }
}
