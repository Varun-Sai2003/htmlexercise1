import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DishService {
  mesg:string = 'Diddy';
  constructor() { }
}
