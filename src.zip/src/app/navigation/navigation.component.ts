import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-navigation',
  imports: [],
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.css'
})
export class NavigationComponent {
// @Input() color: string = 'Chili Red';
@Output() colorChange = new EventEmitter<string>();
colorHandler(p:any){
  this.colorChange.emit(p.value);
}

}
