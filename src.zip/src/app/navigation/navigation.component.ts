import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import { DishService } from '../services/dish.service';

@Component({
  selector: 'app-navigation',
  imports: [],
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.css'
})
export class NavigationComponent {
// @Input() color: string = 'Chili Red';
// s=Inject(DishService);
constructor(public s:DishService) {
 }
@Output() colorChange = new EventEmitter<string>();
colorHandler(p:any){
  this.colorChange.emit(p.value);
}

}
