import { Component } from '@angular/core';
import { Dish } from '../models/dish';
import { FormsModule } from '@angular/forms';
import { ShowDishesComponent } from "../show-dishes/show-dishes.component";

@Component({
  selector: 'app-add-dish',
  imports: [FormsModule, ShowDishesComponent],
  templateUrl: './add-dish.component.html',
  styleUrl: './add-dish.component.css'
})
export class AddDishComponent {
  
  d:Dish = new Dish();
  dishes:Array<Dish> = [];
  constructor() {

  }


  addHandler(){
    this.dishes.push(this.d);
    this.d = new Dish();
    alert('Dish Added');
  }
}
 