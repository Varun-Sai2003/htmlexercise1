export class Cart {
    id?:string;
    email?:string;
    code?:string;
    name?:string;
    price?:number;
    quantity?:number;
}