import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Dish } from '../models/dish';
import { HttpClient } from '@angular/common/http';
import { Cart } from '../models/cart';

@Injectable({
  providedIn: 'root'
})
export class DishService {
  dishes:Array<Dish> = [];
  constructor(private client:HttpClient) { 
    this.getDishes();
  }

  getDishes():Observable<Array<Dish>>{
    return this.client.get<Array<Dish>>('http://localhost:4000/dishes')
  }

  addToCart(item:Cart){
    this.client.post('http://localhost:3000/cart',item)
    .subscribe((d)=>{
      let c=parseInt(localStorage.getItem('cart')??'0');
      c++;
      localStorage.setItem('cart',c.toString());
      alert('Item added to cart');
    })
  }

  getCartByItems(email:string){
    this.client.get<Array<Cart>>('http://localhost:3000/cart').subscribe

  }
  
}
