import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  result?:User;
 
  constructor(public client:HttpClient) {}
  validate(email:String,password:string){
      this.client.get<Array<User>>('http://localhost:3000/usage')
      .subscribe(data=>{
        this.result=data.filter((u=>u.email==email && u.password==password))[0];
        console.log('result'+JSON.stringify(this.result));
      });
      if(this.result!==null && this.result!==undefined)
        return true;
      else
      return false;
  
    }

  addUser(u: any) {
      this.client.post('http://localhost:3000/usage', u)
      .subscribe((u) => {
        alert('User added successfully');
      })
  }
}

