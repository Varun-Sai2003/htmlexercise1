import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../services/register.service';
import { User } from '../models/user';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  registerForm: FormGroup= new FormGroup({
    name: new FormControl(null,Validators.required),
    email: new FormControl(null,[Validators.required,Validators.email]),
    mobile: new FormControl(null,Validators.required),
    password: new FormControl(null,[Validators.min(6),Validators.max(15),Validators.required]),
  });


  // constructor(private fb: FormBuilder) {
  //   this.registerForm
  // }
  u: User = new User();
  constructor(public us: RegisterService) { 
    
    }

  handleRegister(){
    this.us.addUser(this.registerForm.value);
    this.registerForm.reset();
  }
}
