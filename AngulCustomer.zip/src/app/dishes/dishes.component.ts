import { Component, Input } from '@angular/core';
import { DishService } from '../services/dish.service';
import { Dish } from '../models/dish';
import { Cart } from '../models/cart'; 

@Component({
  selector: 'app-dishes',
  standalone: false,
  templateUrl: './dishes.component.html',
  styleUrl: './dishes.component.css'
})

export class DishesComponent {
  @Input() items:Array<Dish> = [];
  data:Array<Dish> = [];
  item:Cart = new Cart();
    constructor(private ds:DishService) {
      this.ds.getDishes().subscribe(resp => {this.data=resp;});
    }

    addToCartHandler(item:Dish){
      this.item.email = localStorage.getItem('email')??'';
      this.item.code = item.code?.toString() ?? '';
      this.item.name = item.name;
      this.item.quantity = 0;
      this.item.price = item.price;
      this.ds.addToCart(this.item);
    }
}
