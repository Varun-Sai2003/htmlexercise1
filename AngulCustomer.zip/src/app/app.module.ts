import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, provideHttpClient } from '@angular/common/http';
import { NavigationComponent } from './navigation/navigation.component';
import { DishesComponent } from './dishes/dishes.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ItalicsPipe } from './pipe/italics.pipe';

@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    DishesComponent,
    LoginComponent,
    RegisterComponent,
    ItalicsPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [provideHttpClient()],
  bootstrap: [AppComponent]
})
export class AppModule { }
